//
//  ViewControllerOneCell.m
//  trasitionpractice
//
//  Created by YouLoft_MacMini on 15/11/23.
//  Copyright © 2015年 YouLoft_MacMini. All rights reserved.
//

#import "XWMagicMoveCell.h"


@implementation XWMagicMoveCell



@end
