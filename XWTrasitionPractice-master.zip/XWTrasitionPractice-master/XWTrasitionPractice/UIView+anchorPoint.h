//
//  UIView+anchorPoint.h
//  XWTrasitionPractice
//
//  Created by wazrx on 15/11/25.
//  Copyright © 2015年 YouLoft_MacMini. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (anchorPoint)

- (void)setAnchorPointTo:(CGPoint)point;

@end
