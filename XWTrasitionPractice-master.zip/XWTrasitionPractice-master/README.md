# XWTrasitionPractice
四个自定义转场动画的demo
####DEMO ONE：一个弹性的present动画，支持手势present和dismiss
![弹性pop](http://ww3.sinaimg.cn/mw690/5ededce5gw1eyfbyf5jnbg208u0g9npd.gif)

####DEMO TWO：一个类似于KeyNote的神奇移动效果push动画，支持手势pop
![神奇移动](http://ww4.sinaimg.cn/mw690/5ededce5gw1eyfc2sx6yeg208u0g9kjl.gif)

####DEMO THREE：一个翻页push效果，支持手势PUSH和POP
![翻页效果](http://ww2.sinaimg.cn/mw690/5ededce5gw1eyfc21jdxkg208u0g9kjm.gif)

####DEMO FOUR：一个小圆点扩散present效果，支持手势dimiss
![扩散效果](http://ww1.sinaimg.cn/mw690/5ededce5gw1eyfc3j26zlg208u0g9kjl.gif)
